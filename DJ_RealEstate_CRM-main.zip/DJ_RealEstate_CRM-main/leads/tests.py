# from django.test import TestCase

# # Create your tests here.
# class LandingPageTest(TestCase):
#     def test_status_code(self):


#     def test_template_name(self):

